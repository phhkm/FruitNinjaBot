package com.example.fruitninjabot

import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import java.nio.ByteBuffer

class ProjectionService : Service() {

    companion object { @Volatile var dryRun: Boolean = true }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null

    private val detector = FruitDetector()
    private val handler = Handler(Looper.getMainLooper())
    private var processing = false
    private var lastGestureAt = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(7, notification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED)
            ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("resultData")
            ?: return START_NOT_STICKY

        val mgr = getSystemService(MediaProjectionManager::class.java)
        projection = mgr.getMediaProjection(resultCode, data)

        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        reader = ImageReader.newInstance(
            width,
            height,
            android.graphics.PixelFormat.RGBA_8888,
            2
        )

        virtualDisplay = projection!!.createVirtualDisplay(
            "FruitNinjaBot",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface,
            null,
            handler
        )

        reader!!.setOnImageAvailableListener({ r ->
            if (processing) return@setOnImageAvailableListener
            processing = true

            val image = r.acquireLatestImage()
            if (image == null) {
                processing = false
                return@setOnImageAvailableListener
            }

            try {
                val plane = image.planes[0]
                val buffer: ByteBuffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * image.width

                val bitmap = Bitmap.createBitmap(
                    image.width + rowPadding / pixelStride,
                    image.height,
                    Bitmap.Config.ARGB_8888
                )
                bitmap.copyPixelsFromBuffer(buffer)

                val cropped = Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
                bitmap.recycle()

                val targets = detector.detect(cropped)
                cropped.recycle()

                val now = SystemClock.uptimeMillis()

                // Conservative first prototype: one gesture at a time.
                if (!dryRun && targets.size == 1 && now - lastGestureAt > 180) {
                    val target = targets.maxByOrNull { it.radius }
                    if (target != null) {
                        FruitNinjaAccessibilityService.instance
                            ?.slash(target.x, target.y, target.radius)
                        lastGestureAt = now
                    }
                }
            } finally {
                image.close()
                processing = false
            }
        }, handler)

        return START_STICKY
    }

    override fun onDestroy() {
        reader?.close()
        virtualDisplay?.release()
        projection?.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(
                    "fruitbot",
                    "Fruit Ninja Bot",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
    }

    private fun notification(): Notification {
        return Notification.Builder(this, "fruitbot")
            .setContentTitle("Fruit Ninja Bot")
            .setContentText("Screen analysis is running")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
    }
}
