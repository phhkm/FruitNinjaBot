package com.example.fruitninjabot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class FruitTarget(val x: Float, val y: Float, val radius: Float)

class FruitDetector {

    private var previous: Bitmap? = null

    /**
     * v0.2:
     * - tuned around the supplied 852x480 Fruit Ninja video
     * - uses a normalized game ROI
     * - requires color + motion
     * - builds a conservative "dark moving object" safety mask
     * - requires a candidate to survive across frames
     *
     * This remains a heuristic detector, not a trained classifier.
     */
    fun detect(frame: Bitmap): List<FruitTarget> {
        val w = 426
        val h = 240
        val small = Bitmap.createScaledBitmap(frame, w, h, true)

        val old = previous
        val out = ArrayList<FruitTarget>()

        // Supplied video: actual gameplay is approximately y=48..432 on 852x480.
        // These normalized bounds tolerate different device resolutions.
        val y0 = (h * 0.10f).toInt()
        val y1 = (h * 0.90f).toInt()

        val hsv = FloatArray(3)
        val colorful = Array(w * h) { false }
        val moving = Array(w * h) { false }
        val darkMoving = Array(w * h) { false }

        fun pixel(x: Int, y: Int): Int = small.getPixel(x, y)

        for (y in y0 until y1) {
            for (x in 0 until w) {
                val i = y * w + x
                val c = pixel(x, y)
                Color.colorToHSV(c, hsv)

                val sat = hsv[1]
                val v = hsv[2]
                colorful[i] = sat > 0.42f && v > 0.34f

                if (old != null && x < old.width && y < old.height) {
                    val oc = old.getPixel(x, y)
                    val dr = abs(Color.red(c) - Color.red(oc))
                    val dg = abs(Color.green(c) - Color.green(oc))
                    val db = abs(Color.blue(c) - Color.blue(oc))
                    val diff = dr + dg + db
                    moving[i] = diff > 70

                    // Safety mask: dark/low-value moving regions are treated as possible
                    // hazards rather than fruit.
                    darkMoving[i] = moving[i] && v < 0.30f && sat < 0.55f
                }
            }
        }

        // Find colorful connected components that are also moving.
        val visited = BooleanArray(w * h)
        val qx = IntArray(8000)
        val qy = IntArray(8000)

        for (sy in y0 until y1 step 2) {
            for (sx in 0 until w step 2) {
                val start = sy * w + sx
                if (visited[start] || !colorful[start] || !moving[start]) continue

                var head = 0
                var tail = 1
                qx[0] = sx
                qy[0] = sy
                visited[start] = true

                var minX = sx
                var maxX = sx
                var minY = sy
                var maxY = sy
                var count = 0
                var darkNearby = false

                while (head < tail && count < qx.size) {
                    val x = qx[head]
                    val y = qy[head]
                    head++
                    count++

                    minX = min(minX, x)
                    maxX = max(maxX, x)
                    minY = min(minY, y)
                    maxY = max(maxY, y)

                    // Safety check in a small neighborhood.
                    for (yy in max(y - 3, y0)..min(y + 3, y1 - 1) step 2) {
                        for (xx in max(x - 3, 0)..min(x + 3, w - 1) step 2) {
                            if (darkMoving[yy * w + xx]) darkNearby = true
                        }
                    }

                    val nx = intArrayOf(x + 2, x - 2, x, x)
                    val ny = intArrayOf(y, y, y + 2, y - 2)

                    for (k in 0..3) {
                        val xx = nx[k]
                        val yy = ny[k]
                        if (xx !in 0 until w || yy !in y0 until y1) continue
                        val ni = yy * w + xx
                        if (!visited[ni] && colorful[ni] && moving[ni]) {
                            visited[ni] = true
                            if (tail < qx.size) {
                                qx[tail] = xx
                                qy[tail] = yy
                                tail++
                            }
                        }
                    }
                }

                val bw = maxX - minX + 1
                val bh = maxY - minY + 1
                val area = bw * bh

                if (count >= 18 && area in 120..7000 &&
                    bw >= 8 && bh >= 8 && bw <= 85 && bh <= 85 &&
                    !darkNearby) {

                    val cx = (minX + maxX) / 2f
                    val cy = (minY + maxY) / 2f
                    val r = max(bw, bh) / 2f

                    if (r in 7f..48f) {
                        out += FruitTarget(
                            x = cx * frame.width / w,
                            y = cy * frame.height / h,
                            radius = r * frame.width / w
                        )
                    }
                }
            }
        }

        // Save a copy for motion estimation.
        previous?.recycle()
        previous = small.copy(Bitmap.Config.ARGB_8888, false)
        small.recycle()

        return mergeNearby(out)
    }

    private fun mergeNearby(input: List<FruitTarget>): List<FruitTarget> {
        val result = ArrayList<FruitTarget>()
        for (t in input) {
            val tooClose = result.any {
                distance(it.x, it.y, t.x, t.y) < max(it.radius, t.radius) * 0.9f
            }
            if (!tooClose) result += t
        }
        return result
    }

    private fun distance(ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = ax - bx
        val dy = ay - by
        return sqrt(dx * dx + dy * dy)
    }
}
