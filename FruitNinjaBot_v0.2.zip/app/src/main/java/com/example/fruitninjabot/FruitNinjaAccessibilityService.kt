package com.example.fruitninjabot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class FruitNinjaAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: FruitNinjaAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun slash(x: Float, y: Float, radius: Float) {
        // Short diagonal gesture through the target.
        val r = radius.coerceIn(25f, 70f)
        val path = Path().apply {
            moveTo(x - r, y + r)
            lineTo(x + r, y - r)
        }

        val stroke = GestureDescription.StrokeDescription(path, 0, 90)
        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            null,
            null
        )
    }
}
