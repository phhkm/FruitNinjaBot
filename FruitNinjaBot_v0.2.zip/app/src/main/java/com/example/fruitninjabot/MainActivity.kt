package com.example.fruitninjabot

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    companion object { private const val REQ_CAPTURE = 1001 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val status = TextView(this).apply {
            text = "Fruit Ninja Bot v0.2\n" +
                   "این نسخه محافظه‌کار است؛ اگر مطمئن نباشد برش نمی‌زند."
            textSize = 17f
            setPadding(32, 32, 32, 20)
        }

        val accessibility = Button(this).apply {
            text = "Accessibility Settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val dryRun = Switch(this).apply {
            text = "Dry Run (فقط تشخیص، بدون برش)"
            isChecked = true
            setOnCheckedChangeListener { _, checked ->
                ProjectionService.dryRun = checked
            }
        }

        val start = Button(this).apply {
            text = "Start Bot"
            setOnClickListener {
                val mgr = getSystemService(MediaProjectionManager::class.java)
                startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE)
            }
        }

        val stop = Button(this).apply {
            text = "Stop Bot"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ProjectionService::class.java))
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(status)
            addView(accessibility)
            addView(dryRun)
            addView(start)
            addView(stop)
        }
        setContentView(root)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, ProjectionService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("resultData", data)
            }
            startForegroundService(intent)
        }
    }
}
